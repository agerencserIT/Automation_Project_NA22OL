int Light = 23;

void setup() {
  pinMode(Light, OUTPUT);
}

void loop() {
  digitalWrite(Light, HIGH);
  delay(500);
  digitalWrite(Light, LOW);
}